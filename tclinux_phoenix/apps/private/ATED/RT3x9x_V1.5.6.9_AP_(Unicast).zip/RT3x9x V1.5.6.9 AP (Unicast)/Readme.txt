

In windows 7, the QA tool MUST run as an administrator.